# Build Lingua AI using only an Android phone

This project includes a GitHub Actions workflow that builds a debug APK on GitHub-hosted runners. You do not need Android Studio on your phone.

## What you need
- A GitHub account
- Chrome (or another mobile browser)
- Internet access while uploading source and building

## Steps
1. Open https://github.com and sign in (create a free account if needed).
2. Create a new repository named `LinguaAI`. Public or private is your choice.
3. Open the repository in Chrome. If needed, enable **Desktop site** from the browser menu.
4. Upload the project files and folders from this ZIP into the repository root. Do not upload the ZIP itself as the only file; GitHub Actions needs the extracted project structure.
5. Confirm that the repository root contains `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/workflows/android-apk.yml`.
6. Open the **Actions** tab, select **Build Lingua AI APK**, and tap **Run workflow** if it has not started automatically.
7. Wait for the run to finish successfully. Open the completed run and find **Artifacts** near the bottom.
8. Download `LinguaAI-debug-apk`, extract it on your phone, then tap the APK to install. Android may ask you to allow installation from that browser or file manager.

## Important
- A debug APK is for testing, not the final Play Store release.
- The first translation model download needs internet. Once the Tagalog and English models are installed, test the app in Airplane mode.
- Never share your GitHub password or personal access token with anyone.
- If the workflow fails, open the failed run and share the error text or screenshot so the build can be fixed.
