# Lingua AI — Android starter project

Kotlin + Jetpack Compose starter for an offline-first Filipino (Tagalog) ↔ English translator.

## Requirements
- Android Studio with Android SDK 36
- JDK 17
- Internet for first Gradle sync and first language-model download
- Android 6.0 (API 23) or newer

## Run on your Honor X9c
1. Extract this ZIP.
2. Open the `LinguaAI` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Enable Developer options and USB debugging on the phone, connect it to the computer, then press Run.
5. Keep the phone online for the first translation in each direction so ML Kit can download the needed models.
6. After a successful translation, enable Airplane mode and test again.

## Current build scope
- Filipino (Tagalog) ↔ English language selector
- Text translation through Google ML Kit on-device Translation
- First-use model download and visible status/error messages
- Dark and light themes
- Copy and clear actions

## Important
This is a source-code starter project, not a compiled or signed APK. It has not been built or device-tested in this environment. Build it in Android Studio and fix any environment-specific Gradle issues before release.

ML Kit supports Tagalog (`tl`) and English (`en`) for on-device translation. Translation models must be downloaded before offline use. The API is intended for casual translations; quality varies by language pair. See the official docs:
- https://developers.google.com/ml-kit/language/translation/translation-language-support
- https://developers.google.com/ml-kit/language/translation/android

Camera OCR, voice input/output, saved history, and a dedicated language-pack manager are not included in this first starter build yet.

## Structure
```text
LinguaAI/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/linguaai/translator/MainActivity.kt
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts
└── README.md
```
