package com.linguaai.translator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LinguaAiApp() }
    }
}

private enum class AppLanguage(val label: String, val code: String) {
    FILIPINO("Filipino", TranslateLanguage.TAGALOG),
    ENGLISH("English", TranslateLanguage.ENGLISH)
}

@Composable
private fun LinguaAiApp() {
    var darkMode by remember { mutableStateOf(false) }
    val scheme = if (darkMode) darkColorScheme(
        primary = Color(0xFFB6A8FF),
        secondary = Color(0xFF80D8CC),
        background = Color(0xFF10131C),
        surface = Color(0xFF1A2030)
    ) else lightColorScheme(
        primary = Color(0xFF5546C7),
        secondary = Color(0xFF087E75),
        background = Color(0xFFF7F7FC),
        surface = Color.White
    )
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            TranslatorScreen(darkMode, onDarkModeChange = { darkMode = it })
        }
    }
}

@Composable
private fun TranslatorScreen(darkMode: Boolean, onDarkModeChange: (Boolean) -> Unit) {
    var source by remember { mutableStateOf(AppLanguage.FILIPINO) }
    var target by remember { mutableStateOf(AppLanguage.ENGLISH) }
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("First-time setup needs internet to download the language models.") }
    var busy by remember { mutableStateOf(false) }
    var translator by remember { mutableStateOf<Translator?>(null) }
    val clipboard = LocalClipboardManager.current

    DisposableEffect(source, target) {
        output = ""
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(source.code)
            .setTargetLanguage(target.code)
            .build()
        val activeTranslator = Translation.getClient(options)
        translator = activeTranslator
        onDispose { activeTranslator.close() }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Lingua AI", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Offline Translator", color = MaterialTheme.colorScheme.secondary)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Dark", fontSize = 12.sp)
                Switch(checked = darkMode, onCheckedChange = onDarkModeChange)
            }
        }

        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("LANGUAGES", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    LanguagePicker(source, Modifier.weight(1f)) { if (it != target) source = it }
                    OutlinedButton(onClick = {
                        val old = source; source = target; target = old
                    }) { Text("⇄") }
                    LanguagePicker(target, Modifier.weight(1f)) { if (it != source) target = it }
                }
            }
        }

        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Your text", fontWeight = FontWeight.SemiBold)
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                    decorationBox = { inner ->
                        if (input.isEmpty()) Text("Type or paste something to translate…",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        inner()
                    }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { input = ""; output = "" }, modifier = Modifier.weight(1f)) {
                        Text("Clear")
                    }
                    Button(
                        onClick = {
                            val current = translator ?: return@Button
                            busy = true
                            status = "Checking/downloading language models…"
                            current.downloadModelIfNeeded(DownloadConditions.Builder().build())
                                .addOnSuccessListener {
                                    status = "Model ready. Translating…"
                                    current.translate(input.trim())
                                        .addOnSuccessListener { translated ->
                                            output = translated
                                            status = "Translation complete. You can now test in Airplane mode."
                                            busy = false
                                        }
                                        .addOnFailureListener { error ->
                                            status = "Translation failed: ${error.localizedMessage ?: "Unknown error"}"
                                            busy = false
                                        }
                                }
                                .addOnFailureListener { error ->
                                    status = "Model setup failed. Connect to the internet once, then retry. ${error.localizedMessage ?: ""}"
                                    busy = false
                                }
                        },
                        enabled = input.isNotBlank() && !busy,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (busy) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text("Translate")
                    }
                }
            }
        }

        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Translation", fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { if (output.isNotBlank()) clipboard.setText(AnnotatedString(output)) },
                        enabled = output.isNotBlank()) { Text("Copy") }
                }
                Text(output.ifBlank { "Your translation will appear here." },
                    fontSize = 17.sp,
                    color = if (output.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface)
            }
        }

        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Offline status", fontWeight = FontWeight.Bold)
                Text(status, fontSize = 13.sp)
                Text("Download both language models once while online. After successful setup, translation runs on this device without sending your text to a server.",
                    fontSize = 12.sp)
            }
        }
        Text("Lingua AI • v1.0.0 • Filipino ↔ English", Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center, fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LanguagePicker(value: AppLanguage, modifier: Modifier = Modifier,
                           onChange: (AppLanguage) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(value.label, maxLines = 1)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            AppLanguage.values().forEach { language ->
                DropdownMenuItem(text = { Text(language.label) }, onClick = {
                    onChange(language); expanded = false
                })
            }
        }
    }
}
